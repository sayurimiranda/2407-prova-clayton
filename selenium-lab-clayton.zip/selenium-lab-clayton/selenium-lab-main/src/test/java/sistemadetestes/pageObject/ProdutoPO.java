package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProdutoPO extends BasePO {
    
    @FindBy(id = "nomeProduto")
    public WebElement inputNomeProduto;

    @FindBy(id = "descricaoProduto")
    public WebElement inputDescricaoProduto;

    @FindBy(id = "precoProduto")
    public WebElement inputPrecoProduto;

    @FindBy(id = "quantidadeProduto")
    public WebElement inputQuantidadeProduto;

    @FindBy(id = "botaoCadastrar")
    public WebElement botaoCadastrar;

    public ProdutoPO(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }
    
    public void cadastrarProduto(String nome, String descricao, String preco, String quantidade) {
        inputNomeProduto.sendKeys(nome);
        inputDescricaoProduto.sendKeys(descricao);
        inputPrecoProduto.sendKeys(preco);
        inputQuantidadeProduto.sendKeys(quantidade);
        botaoCadastrar.click();
    }
}

//  Este arquivo representa o Page Object para a página de cadastro de produtos, mapeando os elementos da página e fornecendo um método para cadastrar produtos.