package tests;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObject.ProdutoPO;

public class ProdutoTest {

    @Test
    public void TC001_deveCadastrarProdutoComCamposPreenchidosCorretamente() {
        WebDriver driver = new ChromeDriver();
        driver.get("URL_DA_PAGINA_DE_CADASTRO");

        ProdutoPO produtoPO = new ProdutoPO(driver);
        produtoPO.cadastrarProduto("Produto A", "Descrição do Produto A", "50.00", "5");

        // Verificar se o produto foi cadastrado com sucesso
        String mensagemSucesso = driver.findElement(By.id("mensagemSucesso")).getText();
        Assert.assertEquals("Produto cadastrado com sucesso!", mensagemSucesso);

        driver.quit();
    }

    @Test
    public void TC002_deveMostrarErroAoDeixarCamposObrigatoriosEmBranco() {
        WebDriver driver = new ChromeDriver();
        driver.get("URL_DA_PAGINA_DE_CADASTRO");

        ProdutoPO produtoPO = new ProdutoPO(driver);
        produtoPO.cadastrarProduto("", "", "", "");

        // Verificar se a mensagem de erro é exibida
        String mensagemErro = driver.findElement(By.id("mensagemErro")).getText();
        Assert.assertEquals("Os campos são obrigatórios!", mensagemErro);

        driver.quit();
    }

    @Test
    public void TC003_deveMostrarErroAoInserirPrecoNaoNumerico() {
        WebDriver driver = new ChromeDriver();
        driver.get("URL_DA_PAGINA_DE_CADASTRO");

        ProdutoPO produtoPO = new ProdutoPO(driver);
        produtoPO.cadastrarProduto("Produto B", "Descrição do Produto B", "abc", "3");

        // Verificar se a mensagem de erro é exibida
        String mensagemErro = driver.findElement(By.id("mensagemErro")).getText();
        Assert.assertEquals("O preço deve ser um valor numérico!", mensagemErro);

        driver.quit();
    }
}

// Este arquivo contém os testes automatizados para os casos de teste selecionados, utilizando o Selenium WebDriver para interagir com o front-end e asserções para verificar os resultados esperados.